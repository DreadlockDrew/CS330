#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <math.h>
using namespace std;

const float DEG2RAD = 3.14159 / 180;
int windowWidth = 500;
int windowHeight = 500;
int maxBricks = 10;
void processInput(GLFWwindow* window);
const int maxCircles = 10;

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick
{
public:
	float red, green, blue;
	float x, y, width;
	BRICKTYPE brick_type;
	ONOFF onoff;
	int health;

	Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
	{
		brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb;
		onoff = ON;
		health = 3;
	};

	void drawBrick()
	{
		if (onoff == ON)
		{
			double halfside = width / 2;

			glColor3d(red, green, blue);
			glBegin(GL_POLYGON);

			glVertex2d(x + halfside, y + halfside);
			glVertex2d(x + halfside, y - halfside);
			glVertex2d(x - halfside, y - halfside);
			glVertex2d(x - halfside, y + halfside);

			glEnd();
		}
	}
};

class Circle
{
public:
	float red, green, blue;
	float radius;
	float x;
	float y;
	float speed = 0.03;
	int direction; // 1=up 2=right 3=down 4=left 5 = up right   6 = up left  7 = down right  8= down left

	Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
	{
		x = xx;
		y = yy;
		radius = rr;
		red = r;
		green = g;
		blue = b;
		radius = rad;
		direction = dir;
	}

	void CheckCollision(Brick* brk)
	{
		if (brk->brick_type == REFLECTIVE )
		{
			brk->red = rand() / 10000;
			brk->green = rand() / 10000;
			brk->blue = rand() / 10000;

			if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width) )
			{
				direction = GetRandomDirection();
				x = x + 0.03;
				y = y + 0.04;
	
			}
		}
		else if (brk->brick_type == DESTRUCTABLE)
		{
			if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width) )
			{

				if (brk->health <= 0)
				{
					brk->onoff = OFF;

				}


				else
				{
					brk->health = brk->health - 1;
					brk->red = rand() / 10000;
					brk->green = rand() / 10000;
					brk->blue = rand() / 10000;
					direction = GetRandomDirection();
					x = x + 0.03;
					y = y + 0.04;
				}
				
			}
		}
	}

	void CheckCollision(Circle* crcl)
	{
			float distance=sqrt(pow(std::abs(x - crcl->x), 2.0)+ pow(std::abs(y - crcl->y), 2.0));

 			if (distance<radius+crcl->radius)
			{
				this->red = rand() / 10000;
				this->green = rand() / 10000;
				this->blue = rand() / 10000;
				direction = GetRandomDirection();
			}


	}
	int GetRandomDirection()
	{
		return (rand() % 8) + 1;
	}

	void MoveOneStep()
	{
		if (direction == 1 || direction == 5 || direction == 6)  // up
		{
			if (y > -1 + radius)
			{
				y -= speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 2 || direction == 5 || direction == 7)  // right
		{
			if (x < 1 - radius)
			{
				x += speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 3 || direction == 7 || direction == 8)  // down
		{
			if (y < 1 - radius) {
				y += speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 4 || direction == 6 || direction == 8)  // left
		{
			if (x > -1 + radius) {
				x -= speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}
	}

	void DrawCircle()
	{
		glColor3f(red, green, blue);
		glBegin(GL_POLYGON);
		for (int i = 0; i < 360; i++) {
			float degInRad = i * DEG2RAD;
			glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
		}
		glEnd();
	}
};

vector<Circle> spheres;
vector<Brick> bricks;


int main(void) {
	srand(time(NULL));

	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	GLFWwindow* window = glfwCreateWindow(480, 480, "Random World of Circles", NULL, NULL);
	if (!window) {
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);







	float x = -.5;
	float y = .66;
	float scale = .1;
	for (int i = 0; i < maxBricks; i++)
	{	
		for (int j = 0; j < 2; j++)
		{
			double r, g, b;
			r = rand() / 10000;
			g = rand() / 10000;
			b = rand() / 10000;
			Brick B(DESTRUCTABLE, x + (i * scale), y+(j*scale), scale, r, g, b);
			bricks.push_back(B);
		}

	}








	while (!glfwWindowShouldClose(window)) {
		//Setup View
		float ratio;
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		ratio = width / (float)height;
		glViewport(0, 0, width, height);
		glClear(GL_COLOR_BUFFER_BIT);

		processInput(window);

		//Movement
		for (int i = 0; i < spheres.size(); i++)
		{
			for(int h=0;h<bricks.size();h++)
			{ 
				spheres[i].CheckCollision(&bricks[i]);
			}
			for (int q = 0; q < spheres.size();q++)
			{

				for (int w = 0; w < spheres.size();w++)
				{
					if (q != w)
					{
						spheres[q].CheckCollision(&spheres[w]);
					}
				}
			}
			spheres[i].MoveOneStep();
			spheres[i].DrawCircle();

		}
		for (int i = 0; i < bricks.size();i++)
		{
			bricks[i].drawBrick();
		}
		

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate;
	exit(EXIT_SUCCESS);
}


void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS && spheres.size()<=maxCircles)
	{
		double r, g, b;
		r = rand() / 10000;
		g = rand() / 10000;
		b = rand() / 10000;
		Circle B(0, 0, 02, 2, 0.05, r, g, b);
		spheres.push_back(B);
	}
}