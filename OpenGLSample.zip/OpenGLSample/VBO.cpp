#include"VBO.h"

/*vertex buffers allow us send a lot of data to the GPU all at once(optimal) we will store our vertex data in the VBO
* vertex array objects store pointer sto one or more VBOS and tells openLG how to interpret them
*/
// Constructor that generates a Vertex Buffer Object and links it to vertices
VBO::VBO(GLfloat* vertices, GLsizeiptr size)
{	//Creates a buffer object with only (1) 3d object
	glGenBuffers(1, &ID);
	glBindBuffer(GL_ARRAY_BUFFER, ID);

		/*
	!Lets store our vertices in the *current* VBO!

	STREAM means vertices are modifed once and used a few times.
	STATIC means modified once and used many times.
	DYNAMIC means modified many times and used many many times.

	DRAW means vertices will be modified and used to draw an image on the screen READ and COPY are self explanitory 
	*/
	glBufferData(GL_ARRAY_BUFFER, size, vertices, GL_STATIC_DRAW);
}

// Binds the VBO
void VBO::Bind()
{	//Bind (make current) the VBO as an array buffer (buffer actions will hapen to this buffer now. Whenever we utelize a function that modifies the (current object) we will modify this object now
	glBindBuffer(GL_ARRAY_BUFFER, ID);
}

// Unbinds the VBO
void VBO::Unbind()
{
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

// Deletes the VBO
void VBO::Delete()
{
	glDeleteBuffers(1, &ID);
}