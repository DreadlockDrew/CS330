/*





	//////////////////////////////////////////////////////////////////////////////////////////////





		



		//pinkMetalTex.Bind();
		//VAO5.Bind();
		//glDrawElements(GL_TRIANGLES, sizeof(PhoneHolderStalk.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);


		//pinkMetalTex.Bind();
		//PhoneHolderBaseVAO.Bind();
		//glDrawElements(GL_TRIANGLES, sizeof(PhoneHolderBase.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);


		



		// Tells OpenGL which Shader Program we want to use
		lightShader.Activate();
		// Export the camMatrix to the Vertex Shader of the light cube
		camera.Matrix(lightShader, "camMatrix");
		// Bind the VAO so OpenGL knows to use it
		lightVAO.Bind();
		// Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(lightIndices) / sizeof(int), GL_UNSIGNED_INT, 0);

		// Swap the back buffer with the front buffer
		glfwSwapBuffers(window);
		// Take care of all GLFW events
		glfwPollEvents();
	}



	// Delete all the objects we've created
	VAO1.Delete();
	VBO1.Delete();
	EBO1.Delete();

	VAO2.Delete();
	VBO2.Delete();
	EBO2.Delete();

	VAO3.Delete();
	VBO3.Delete();
	EBO3.Delete();

	brickTex.Delete();
	woodTex.Delete();
	brickTex.Delete();

	shaderProgram.Delete();
	// Delete window before ending the program
	glfwDestroyWindow(window);
	// Terminate GLFW before ending the program
	glfwTerminate();
	return 0;
}

*/