#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

#include <iostream>


const char* const WINDOW_TITLE = "Tutorial 2.2"; // Macro for window title

// Variables for window width and height
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;



int main(int argc, char* argv[])
{
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	GLFWwindow* window;
	//Intialize window
	if (!glfwInit)
	{
		return -1;
	}

	//Create a windowed mode window and its openGL context.
	window = glfwCreateWindow(WINDOW_HEIGHT, WINDOW_WIDTH, "Hello World", NULL, NULL);
	if (!window)
	{
		glfwTerminate(); return -1;
	}

	//make the window the current context.
	glfwMakeContextCurrent(window);

	glViewport(0.0f, 0.0f, WINDOW_WIDTH, WINDOW_WIDTH);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, WINDOW_WIDTH, 0, WINDOW_HEIGHT, 0, 600);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	GLfloat v[9] =
	{
	320,290,0,
	270,190,0,
	370,190,0
	};

	GLfloat v2[9] =
	{
	320 + 100,290,0,
	270 + 100,190,0,
	370 + 100,190,0
	};

	GLfloat color[9] =
	{
	255,0,0,
	0,255,0,
	0,0,255
	};

	while (!glfwWindowShouldClose(window))
	{
		glClear(GL_COLOR_BUFFER_BIT);

		glEnableClientState(GL_VERTEX_ARRAY);//Tell openGl your using a fixed vertex array for fixed function attributes
		glEnableClientState(GL_COLOR_ARRAY);

		glVertexPointer(3, GL_FLOAT, 0, v);//point to the vertices to be used
		glColorPointer(3, GL_FLOAT, 0, color);//points to the colors to be used
		glDrawArrays(GL_TRIANGLES, 0, 3);//draw the vertices

		glDisableClientState(GL_VERTEX_ARRAY);//Tell openGL you are finished using the vertex array attribute
		glDisableClientState(GL_COLOR_ARRAY);//Tell openGL you are finished using the vertex array attribute

		//swap front and back buffers
		glfwSwapBuffers(window);

	}
}