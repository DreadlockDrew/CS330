#ifndef RECTPRISM_H
#define RECTPRISM_H

#include "VBO.H"
#include<glad/glad.h>
#include<string>
#include<fstream>
#include<sstream>
#include<iostream>
#include<cerrno>

class RectPrism
{
public:
	// Reference ID of the Shader Program
	GLuint Scale;
	//was 192 but now 192 + 24*3=264
	GLfloat internalVerts[264] = {};
	GLuint Indices[36] =
	{
		/////////////FRONT
		4,7,6,
		5,4,6,
		/////////////BACK
		0,1,2,
		0,3,2,
		/////////////LEFT
		11,9,8,
		11,9,10,

		/////////////RIGHT
		14,12,13,
		14,12,15,

		/////////////TOP
		17,16,18,
		19,18,16,

		////////////BOTTOM
		21,20,22,
		20,22,23,

	};

	// Constructor that build the cube from
	RectPrism(GLfloat originX, GLfloat originY, GLfloat originZ, GLfloat Length, GLfloat Height, GLfloat Width);

	void EditProperties(std::string property, int payloadSize, GLfloat payload[]);


public:
	// Checks if the different Shaders have compiled properly
	void EditProperties(std::string property,int payloadSize, const char* payload);

private:
	// Checks if the different Shaders have compiled properly
	void compileErrors(unsigned int shader, const char* type);
};



#endif