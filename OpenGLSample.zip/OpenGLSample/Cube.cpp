#include"Cube.h"


Cube::Cube(GLfloat originX, GLfloat originY, GLfloat originZ, GLfloat edgeLength, GLfloat Scale = 1)
{
    GLfloat centerPosX = originX * Scale;
    GLfloat centerPosY = originY * Scale;
    GLfloat centerPosZ = originZ * Scale;
    GLfloat halfSideLength = edgeLength * 0.5f;

   
    GLfloat cubeVertices[]    =
    {
            // front face
            centerPosX - halfSideLength, centerPosY + halfSideLength, centerPosZ + halfSideLength, // top left 0
            centerPosX + halfSideLength, centerPosY + halfSideLength, centerPosZ + halfSideLength, // top right 1
            centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength, // bottom right 2
            centerPosX - halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength, // bottom left 3

            // back face
            centerPosX - halfSideLength, centerPosY + halfSideLength, centerPosZ - halfSideLength, // top left 4
            centerPosX + halfSideLength, centerPosY + halfSideLength, centerPosZ - halfSideLength, // top right 5 
            centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // bottom right 6
            centerPosX - halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // bottom left 7
            
            // left face
            centerPosX - halfSideLength, centerPosY + halfSideLength, centerPosZ + halfSideLength, // top left 8
            centerPosX - halfSideLength, centerPosY + halfSideLength, centerPosZ - halfSideLength, // top right 9
            centerPosX - halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // bottom right 10
            centerPosX - halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength, // bottom left 11
            
            // right face
            centerPosX + halfSideLength, centerPosY + halfSideLength, centerPosZ + halfSideLength, // top left 12
            centerPosX + halfSideLength, centerPosY + halfSideLength, centerPosZ - halfSideLength, // top right 13
            centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // bottom right 14 
            centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength, // bottom left 15

            // top face
            centerPosX - halfSideLength, centerPosY + halfSideLength, centerPosZ + halfSideLength, // top left 16
            centerPosX - halfSideLength, centerPosY + halfSideLength, centerPosZ - halfSideLength, // top right 17
            centerPosX + halfSideLength, centerPosY + halfSideLength, centerPosZ - halfSideLength, // bottom right 18
            centerPosX + halfSideLength, centerPosY + halfSideLength, centerPosZ + halfSideLength, // bottom left 19

            // bottom face                                                                                                                                                                           // right face
            centerPosX - halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength, // top left 20
            centerPosX - halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // top right 21
            centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // bottom right 22
            centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength, // bottom left  23                                                                                                                                                                                                                                                                                                                                                                                                                                               centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // bottom right                                                                                                                                                                                                                                                                                                                                                                                                                                                  centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength  // bottom left
            
    };
    GLfloat colourVertices[]  = 
    {
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    255.0f, 255.0f, 255.0f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f,0.9f,0.9f,
    };
    GLfloat textureVertices[] = 
    {   
        /////////////FRONT
        0.0f,1.0f,   //top left 0
        1.0f,1.0f,   //top right 1
        1.0f,0.0f,   //2 bottom right
        0.0f,0.0f,   //3 bottom left
        /////////////BACK
        0.0f,1.0f,   //4 top left 
        1.0f,1.0f,   //5 top right
        1.0f,0.0f,   //6 bottom right
        0.0f,0.0f,   //7 bottom left
        /////////////LEFT
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left
        /////////////RIGHT
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left
        /////////////TOP
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left
        /////////////BOTTOM
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left

        
    };

    for (int i = 0; i <= 23; i = i + 1)
    {   
        ///////////////////////////////////////////////////
        internalVerts[i * 8] = cubeVertices[i*3];
        internalVerts[i * 8 + 1] = cubeVertices[i*3 + 1];
        internalVerts[i * 8 + 2] = cubeVertices[i*3 + 2];
        ///////////////////////////////////////////////////
        internalVerts[i * 8 + 3] = colourVertices[i*3];
        internalVerts[i * 8 + 4] = colourVertices[i*3 + 1];
        internalVerts[i * 8 + 5] = colourVertices[i*3 + 2];
        ///////////////////////////////////////////////////
        internalVerts[i * 8 + 6] = textureVertices[i*2];
        internalVerts[i * 8 + 7] = textureVertices[i*2 + 1];
        
    };

}
