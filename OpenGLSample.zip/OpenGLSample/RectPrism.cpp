#include "RectPrism.h"


RectPrism::RectPrism(GLfloat originX, GLfloat originY, GLfloat originZ, GLfloat Length, GLfloat Height, GLfloat Width)

{
    //Modifiable position variables
    GLfloat centerPosX = originX;
    GLfloat centerPosY = originY;
    GLfloat centerPosZ = originZ;
    


    

    GLfloat LocationVertices[] =
    {
        // front face
        centerPosX - Length / 2, centerPosY + Height / 2, centerPosZ + Width / 2, // top left 0
        centerPosX + Length / 2, centerPosY + Height / 2, centerPosZ + Width / 2, // top right 1
        centerPosX + Length / 2, centerPosY - Height / 2, centerPosZ + Width / 2, // bottom right 2
        centerPosX - Length / 2, centerPosY - Height / 2, centerPosZ + Width / 2, // bottom left 3

        // back face
        centerPosX - Length / 2, centerPosY + Height / 2, centerPosZ - Width / 2, // top left 4
        centerPosX + Length / 2, centerPosY + Height / 2, centerPosZ - Width / 2, // top right 5 
        centerPosX + Length / 2, centerPosY - Height / 2, centerPosZ - Width / 2, // bottom right 6
        centerPosX - Length / 2, centerPosY - Height / 2, centerPosZ - Width / 2, // bottom left 7

        // left face
        centerPosX - Length / 2, centerPosY + Height / 2, centerPosZ + Width / 2, // top left 8
        centerPosX - Length / 2, centerPosY + Height / 2, centerPosZ - Width / 2, // top right 9
        centerPosX - Length / 2, centerPosY - Height / 2, centerPosZ - Width / 2, // bottom right 10
        centerPosX - Length / 2, centerPosY - Height / 2, centerPosZ + Width / 2, // bottom left 11

        // right face
        centerPosX + Length / 2, centerPosY + Height / 2, centerPosZ + Width / 2, // top left 12
        centerPosX + Length / 2, centerPosY + Height / 2, centerPosZ - Width / 2, // top right 13
        centerPosX + Length / 2, centerPosY - Height / 2, centerPosZ - Width / 2, // bottom right 14 
        centerPosX + Length / 2, centerPosY - Height / 2, centerPosZ + Width / 2, // bottom left 15

        // top face
        centerPosX - Length / 2, centerPosY + Height / 2, centerPosZ + Width / 2, // top left 16
        centerPosX - Length / 2, centerPosY + Height / 2, centerPosZ - Width / 2, // top right 17
        centerPosX + Length / 2, centerPosY + Height / 2, centerPosZ - Width / 2, // bottom right 18
        centerPosX + Length / 2, centerPosY + Height / 2, centerPosZ + Width / 2, // bottom left 19

        // bottom face                                                                                                                                                                           // right face
        centerPosX - Length / 2, centerPosY - Height / 2, centerPosZ + Width / 2, // top left 20
        centerPosX - Length / 2, centerPosY - Height / 2, centerPosZ - Width / 2, // top right 21
        centerPosX + Length / 2, centerPosY - Height / 2, centerPosZ - Width / 2, // bottom right 22
        centerPosX + Length / 2, centerPosY - Height / 2, centerPosZ + Width / 2, // bottom left  23                                                                                                                                                                                                                                                                                                                                                                                                                                               centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ - halfSideLength, // bottom right                                                                                                                                                                                                                                                                                                                                                                                                                                                  centerPosX + halfSideLength, centerPosY - halfSideLength, centerPosZ + halfSideLength  // bottom left

    };

    //The color vertices (which I do not focus in favour of textures
    GLfloat colourVertices[] =
    {
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    255.0f, 255.0f, 255.0f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f, 0.3f, 0.2f,
    0.2f, 0.9f, 0.3f,
    0.2f, 0.3f, 0.9f,
    0.9f,0.9f,0.9f,
    };

    //Texture vertices correctly mapping a texture onto the sides of a prism
    GLfloat textureVertices[] =
    {
        /////////////FRONT
        0.0f,1.0f,   //top left 0
        1.0f,1.0f,   //top right 1
        1.0f,0.0f,   //2 bottom right
        0.0f,0.0f,   //3 bottom left
        /////////////BACK
        0.0f,1.0f,   //4 top left 
        1.0f,1.0f,   //5 top right
        1.0f,0.0f,   //6 bottom right
        0.0f,0.0f,   //7 bottom left
        /////////////LEFT
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left
        /////////////RIGHT
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left
        /////////////TOP
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left
        /////////////BOTTOM
        0.0f,1.0f,   //8 top left
        1.0f,1.0f,   //9 top right
        1.0f,0.0f,   //10 bottom right
        0.0f,0.0f,   //11 bottom left


    };

    GLfloat normalVertices[]=
  
    {
        //FRONT
        0.0f, -1.0f, 0.0f, // Bottom side 0
        0.0f, -1.0f, 0.0f, // Bottom side 1
        0.0f, -1.0f, 0.0f, // Bottom side 2
        0.0f, -1.0f, 0.0f, // Bottom side 3
        //BACK
        -0.8f, 0.5f,  0.0f, // Left Side 4
        -0.8f, 0.5f,  0.0f, // Left Side 5
        -0.8f, 0.5f,  0.0f, // Left Side 6
        -0.8f, 0.5f,  0.0f, // Left Side 7
        //LEFT
        -0.8f, 0.5f,  0.0f, // Left Side 8
        -0.8f, 0.5f,  0.0f, // Left Side 9   
        -0.8f, 0.5f,  0.0f, // Left Side 10
        -0.8f, 0.5f,  0.0f, // Left Side 11
        //RIGHT
        0.8f, 0.5f,  0.0f, // Right side 12
        0.8f, 0.5f,  0.0f, // Right side 13
        0.8f, 0.5f,  0.0f, // Right side 14
        0.8f, 0.5f,  0.0f, // Right side 15
        //TOP
        0.0f, 0.5f,  0.8f, // Facing side 16
        0.0f, 0.5f,  0.8f, // Facing side 17
        0.0f, 0.5f,  0.8f,  // Facing side 18
        0.0f, 0.5f,  0.8f,  // Facing side 19
        //BOTTOM
        0.0f, 0.5f, -0.8f, // Non-facing side 20
        0.0f, 0.5f, -0.8f, // Non-facing side 21
        0.0f, 0.5f, -0.8f, // Non-facing side 22
        0.0f, 0.5f, -0.8f, // Non-facing side 23
    };

    //24(3+3+2+3)=264
    //A for loop for building the internal vertices so that they match previous examples
    for (int i = 0; i <= 23; i = i + 1)
    {
        ///////////////////////////////////////////////////
        internalVerts[i * 11] = LocationVertices[i * 3];
        internalVerts[i * 11 + 1] = LocationVertices[i * 3 + 1];
        internalVerts[i * 11 + 2] = LocationVertices[i * 3 + 2];
        ///////////////////////////////////////////////////
        internalVerts[i * 11 + 3] = colourVertices[i * 3];
        internalVerts[i * 11 + 4] = colourVertices[i * 3 + 1];
        internalVerts[i * 11 + 5] = colourVertices[i * 3 + 2];
        ///////////////////////////////////////////////////
        internalVerts[i * 11 + 6] = textureVertices[i * 2];
        internalVerts[i * 11 + 7] = textureVertices[i * 2 + 1];
        ///////////////////////////////////////////////////
        internalVerts[i * 11 + 8] = normalVertices[i * 3];
        internalVerts[i * 11 + 9] = normalVertices[i * 3 + 1];
        internalVerts[i * 11 + 10] = normalVertices[i * 3 + 2];
    };
}

void RectPrism::EditProperties(std::string property, int payloadSize, GLfloat payload[])
{
    if (property == "lighting")
    {
        for (int i = 0; i < payloadSize; i++)

        {
            internalVerts[i * 11 + 8] = payload[i * 3];
            internalVerts[i * 11 + 9] = payload[i * 3 + 1];
            internalVerts[i * 11 + 10] = payload[i * 3 + 2];
        }


    }
}

// a error compiler function used in non release versions of my code proffesor
void RectPrism::compileErrors(unsigned int shader, const char* type)
{
}
