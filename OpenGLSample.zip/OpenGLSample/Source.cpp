﻿#include<iostream>
#include<glad/glad.h>
#include<GLFW/glfw3.h>
#include"stb_image.h"
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>

#include"Texture.h"
#include"shaderClass.h"
#include"VAO.h"
#include"VBO.h"
#include"EBO.h"
#include"Camera.h"
#include"RectPrism.h"


const unsigned int windowWidth = 800;
const unsigned int windowHeight = 800;

Camera HostCamera = Camera(windowWidth, windowHeight, glm::vec3(0.0f, 0.0f, 2.0f));;

void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);

// Vertices coordinates
GLfloat vertices[] =
{ //     COORDINATES     /        COLORS          /    TexCoord   /        NORMALS       //
	-0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f, 	 0.0f, 0.0f,      0.0f, -1.0f, 0.0f, // Bottom side
	-0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	 0.0f, 5.0f,      0.0f, -1.0f, 0.0f, // Bottom side
	 0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	 5.0f, 5.0f,      0.0f, -1.0f, 0.0f, // Bottom side
	 0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f,	 5.0f, 0.0f,      0.0f, -1.0f, 0.0f, // Bottom side

	-0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f, 	 0.0f, 0.0f,     -0.8f, 0.5f,  0.0f, // Left Side (darker)
	-0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	 5.0f, 0.0f,     -0.8f, 0.5f,  0.0f, // Left Side
	 0.0f, 0.8f,  0.0f,     0.92f, 0.86f, 0.76f,	 2.5f, 5.0f,     -0.8f, 0.5f,  0.0f, // Left Side

	-0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	 5.0f, 0.0f,      0.0f, 0.5f, -0.8f, // Non-facing side
	 0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	 0.0f, 0.0f,      0.0f, 0.5f, -0.8f, // Non-facing side
	 0.0f, 0.8f,  0.0f,     0.92f, 0.86f, 0.76f,	 2.5f, 5.0f,      0.0f, 0.5f, -0.8f, // Non-facing side

	 0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	 0.0f, 0.0f,      0.8f, 0.5f,  0.0f, // Right side (lighter)
	 0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f,	 5.0f, 0.0f,      0.8f, 0.5f,  0.0f, // Right side
	 0.0f, 0.8f,  0.0f,     0.92f, 0.86f, 0.76f,	 2.5f, 5.0f,      0.8f, 0.5f,  0.0f, // Right side

	 0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f,	 5.0f, 0.0f,      0.0f, 0.5f,  0.8f, // Facing side
	-0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f, 	 0.0f, 0.0f,      0.0f, 0.5f,  0.8f, // Facing side
	 0.0f, 0.8f,  0.0f,     0.92f, 0.86f, 0.76f,	 2.5f, 5.0f,      0.0f, 0.5f,  0.8f  // Facing side
};

// Indices for vertices order
GLuint indices[] =
{
	0, 1, 2, // Bottom side
	0, 2, 3, // Bottom side
	4, 6, 5, // Left side
	7, 9, 8, // Non-facing side
	10, 12, 11, // Right side
	13, 15, 14 // Facing side
};

GLfloat lightVertices[] =
{ //     COORDINATES     //
	-0.1f, -0.1f,  0.1f,
	-0.1f, -0.1f, -0.1f,
	 0.1f, -0.1f, -0.1f,
	 0.1f, -0.1f,  0.1f,
	-0.1f,  0.1f,  0.1f,
	-0.1f,  0.1f, -0.1f,
	 0.1f,  0.1f, -0.1f,
	 0.1f,  0.1f,  0.1f
};

GLfloat lightVertices2[] =
{ //     COORDINATES     //
	-0.1f, -0.1f,  0.1f,
	-0.1f, -0.1f, -0.1f,
	 0.1f, -0.1f, -0.1f,
	 0.1f, -0.1f,  0.1f,
	-0.1f,  0.1f,  0.1f,
	-0.1f,  0.1f, -0.1f,
	 0.1f,  0.1f, -0.1f,
	 0.1f,  0.1f,  0.1f
};

GLuint lightIndices[] =
{
	0, 1, 2,
	0, 2, 3,
	0, 4, 7,
	0, 7, 3,
	3, 7, 6,
	3, 6, 2,
	2, 6, 5,
	2, 5, 1,
	1, 5, 4,
	1, 4, 0,
	4, 5, 6,
	4, 6, 7
};


int nomain()
{
	// Initialize GLFW
	glfwInit();

	// Tell GLFW what version of OpenGL we are using 
	// In this case we are using OpenGL 3.3
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	// Tell GLFW we are using the CORE profile
	// So that means we only have the modern functions
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Create a GLFWwindow object of 800 by 800 pixels
	GLFWwindow* window = glfwCreateWindow(windowWidth, windowHeight, "Avery Sulker", NULL, NULL);
	// Error check if the window fails to create
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	//
	glfwSetScrollCallback(window, UMouseScrollCallback);
	// Introduce the window into the current context
	glfwMakeContextCurrent(window);

	//Load GLAD so it configures OpenGL
	gladLoadGL();
	// Specify the viewport of OpenGL in the Window
	// In this case the viewport goes from x = 0, y = 0, to x = 800, y = 800
	glViewport(0, 0, windowWidth, windowHeight);



	// Generates Shader object using shaders default.vert and default.frag
	Shader shaderProgram("default.vert", "default.frag");

	//END OF SETUPS
	///////////////////////////////////////////////////////////////////////////
	// Generates Vertex Array Object and binds it
	VAO VAO1;
	VAO1.Bind();
	// Generates Vertex Buffer Object and links it to vertices
	VBO VBO1(vertices, sizeof(vertices));
	// Generates Element Buffer Object and links it to indices
	EBO EBO1(indices, sizeof(indices));
	// Links VBO attributes such as coordinates and colors to VAO
	VAO1.LinkAttrib(VBO1, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	VAO1.LinkAttrib(VBO1, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	VAO1.LinkAttrib(VBO1, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	VAO1.LinkAttrib(VBO1, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	// Unbind all to prevent accidentally modifying them
	VAO1.Unbind();
	VBO1.Unbind();
	EBO1.Unbind();
	//PYRAMID
	///////////////////////////////////////////////////////////////////////////
	VAO MonitorBodyVAO;
	MonitorBodyVAO.Bind();

	RectPrism MonitorBody(0.0f, 0.0f, -2.2, 1.0f, 0.8f, 0.064f);
	VBO MonitorBodyVBO(MonitorBody.internalVerts, sizeof(MonitorBody.internalVerts));
	EBO MonitorBodyEBO(MonitorBody.Indices, sizeof(MonitorBody.Indices));



	// Links VBO attributes such as coordinates and colors to VAO
	MonitorBodyVAO.LinkAttrib(MonitorBodyVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	MonitorBodyVAO.LinkAttrib(MonitorBodyVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	MonitorBodyVAO.LinkAttrib(MonitorBodyVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	MonitorBodyVAO.LinkAttrib(MonitorBodyVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	MonitorBodyVAO.Unbind();
	MonitorBodyVBO.Unbind();
	MonitorBodyEBO.Unbind();
	//MONITORBODY
	///////////////////////////////////////////////////////////////////////////
	VAO MonitorContentVAO;
	MonitorContentVAO.Bind();

	RectPrism MonitorContent(0.0f, 0.0f, -2.17, 0.9f, 0.7f, 0.0064f);
	VBO MonitorContentVBO(MonitorContent.internalVerts, sizeof(MonitorContent.internalVerts));
	EBO MonitorContentEBO(MonitorContent.Indices, sizeof(MonitorContent.Indices));



	// Links VBO attributes such as coordinates and colors to VAO
	MonitorContentVAO.LinkAttrib(MonitorContentVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	MonitorContentVAO.LinkAttrib(MonitorContentVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	MonitorContentVAO.LinkAttrib(MonitorContentVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	MonitorContentVAO.LinkAttrib(MonitorContentVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	MonitorContentVAO.Unbind();
	MonitorContentVBO.Unbind();
	MonitorContentEBO.Unbind();
	//MONITORCONTENT
	///////////////////////////////////////////////////////////////////////////
	VAO MonitorStalkVAO;
	MonitorStalkVAO.Bind();
	RectPrism MonitorStalk(0.0f, -0.5f, -2.2, 0.2f, 0.3f, 0.0064f);
	VBO MonitorStalkVBO(MonitorStalk.internalVerts, sizeof(MonitorStalk.internalVerts));
	EBO MonitorStalkEBO(MonitorStalk.Indices, sizeof(MonitorStalk.Indices));

	// Links VBO attributes such as coordinates and colors to VAO
	MonitorStalkVAO.LinkAttrib(MonitorStalkVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	MonitorStalkVAO.LinkAttrib(MonitorStalkVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	MonitorStalkVAO.LinkAttrib(MonitorStalkVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	MonitorStalkVAO.LinkAttrib(MonitorStalkVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	MonitorStalkVAO.Unbind();
	MonitorStalkVBO.Unbind();
	MonitorStalkEBO.Unbind();
	//MONITORSTALK
	///////////////////////////////////////////////////////////////////////////

	VAO MonitorBaseVAO;
	MonitorBaseVAO.Bind();

	RectPrism MonitorBase(0.0f, -0.59f, -2.2, 0.4f, 0.01f, 0.4);
	VBO MonitorBaseVBO(MonitorBase.internalVerts, sizeof(MonitorBase.internalVerts));
	EBO MonitorBaseEBO(MonitorBase.Indices, sizeof(MonitorBase.Indices));

	// Links VBO attributes such as coordinates and colors to VAO
	MonitorBaseVAO.LinkAttrib(MonitorBaseVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	MonitorBaseVAO.LinkAttrib(MonitorBaseVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	MonitorBaseVAO.LinkAttrib(MonitorBaseVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	MonitorBaseVAO.LinkAttrib(MonitorBaseVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	MonitorBaseVAO.Unbind();
	MonitorStalkVBO.Unbind();
	MonitorBaseEBO.Unbind();
	//MONITORBASE
	///////////////////////////////////////////////////////////////////////////
	RectPrism basePlate(0.0f, -0.6f, -1.05, 2.7f, 0.02f, 2.7f);

	VAO basePlateVAO;
	basePlateVAO.Bind();
	VBO basePlateVBO(basePlate.internalVerts, sizeof(basePlate.internalVerts));
	EBO basePlateEBO(basePlate.Indices, sizeof(basePlate.Indices));

	// Links VBO attributes such as coordinates and colors to VAO
	basePlateVAO.LinkAttrib(basePlateVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	basePlateVAO.LinkAttrib(basePlateVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	basePlateVAO.LinkAttrib(basePlateVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	basePlateVAO.LinkAttrib(basePlateVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));

	basePlateVAO.Unbind();
	basePlateVBO.Unbind();
	basePlateEBO.Unbind();
	//BASEPLATE
	///////////////////////////////////////////////////////////////////////////
	GLfloat KeyboardLighting[] =

	{
		//FRONT (facingish)
		0.8f, 0.5f,  0.0f,
		1.0f, 1.0f,  1.0f,
		0.8f, 0.5f,  0.0f, 
		1.0f, 1.0f,  1.0f,
		//BACK (non facing)
		0.0f, 0.5f, -0.8f, // Left Side 4
		0.0f, 0.5f, -0.8f, // Left Side 5
		0.0f, 0.5f, -0.8f, // Left Side 6
		0.0f, 0.5f, -0.8f, // Left Side 7
		//LEFT
		0.8f, 0.5f,  0.0f, // Left Side 8
		0.8f, 0.5f,  0.0f, // Left Side 9   
		0.8f, 0.5f,  0.0f, // Left Side 10
		0.8f, 0.5f,  0.0f, // Left Side 11
		//RIGHT
		-0.8f, 0.5f,  0.0f, // Right side 12
		-0.8f, 0.5f,  0.0f, // Right side 13
		-0.8f, 0.5f,  0.0f, // Right side 14
		-0.8f, 0.5f,  0.0f, // Right side 15
		//TOP (facing)
		0.0f, 0.5f,  0.8f, // Facing side 16
		0.0f, 0.5f,  0.8f, // Facing side 17
		0.0f, 0.5f,  0.8f, // Facing side 18
		0.0f, 0.5f,  0.8f,  // Facing side 19
		//BOTTOM
		0.0f, 0.5f, -0.8f, // Non-facing side 20
		0.0f, 0.5f, -0.8f, // Non-facing side 21
		0.0f, 0.5f, -0.8f, // Non-facing side 22
		0.0f, 0.5f, -0.8f, // Non-facing side 23
	};
	RectPrism Keyboard(0.0f, -0.587f, 0.0, 1.1f, 0.02f, 0.45f);
	VAO KeyboardVAO;
	KeyboardVAO.Bind();
	VBO KeyboardVBO(Keyboard.internalVerts, sizeof(Keyboard.internalVerts));
	EBO KeyboardEBO(Keyboard.Indices, sizeof(Keyboard.Indices));

	// Links VBO attributes such as coordinates and colors to VAO
	KeyboardVAO.LinkAttrib(KeyboardVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	KeyboardVAO.LinkAttrib(KeyboardVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	KeyboardVAO.LinkAttrib(KeyboardVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	KeyboardVAO.LinkAttrib(KeyboardVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));

	KeyboardVAO.Unbind();
	KeyboardVBO.Unbind();
	KeyboardEBO.Unbind();

	//KEYBOARD
	///////////////////////////////////////////////////////////////////////////
	VAO PhoneHolderStalkVAO;
	PhoneHolderStalkVAO.Bind();

	RectPrism PhoneHolderStalk(-1.2f, -0.45f, 0.0, 0.0015f, 0.28f, 0.085f);
	VBO PhoneHolderStalkVBO(PhoneHolderStalk.internalVerts, sizeof(PhoneHolderStalk.internalVerts));
	EBO PhoneHolderStalkEBO(PhoneHolderStalk.Indices, sizeof(PhoneHolderStalk.Indices));



	// Links VBO attributes such as coordinates and colors to VAO
	PhoneHolderStalkVAO.LinkAttrib(PhoneHolderStalkVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	PhoneHolderStalkVAO.LinkAttrib(PhoneHolderStalkVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	PhoneHolderStalkVAO.LinkAttrib(PhoneHolderStalkVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	PhoneHolderStalkVAO.LinkAttrib(PhoneHolderStalkVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	PhoneHolderStalkVAO.Unbind();
	PhoneHolderStalkVBO.Unbind();
	PhoneHolderStalkEBO.Unbind();
	//PHONE HOLDER STALK
	//////////////////////////////////////////////////////////////////////////
	VAO PhoneHolderBaseVAO;
	PhoneHolderBaseVAO.Bind();
	RectPrism PhoneHolderBase(-1.064f, -0.58f, 0.0, 0.30f, 0.0015f, 0.23f);
	VBO PhoneHolderBaseVBO(PhoneHolderBase.internalVerts, sizeof(PhoneHolderBase.internalVerts));
	EBO PhoneHolderBaseEBO(PhoneHolderBase.Indices, sizeof(PhoneHolderBase.Indices));

	PhoneHolderBaseVAO.LinkAttrib(PhoneHolderBaseVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	PhoneHolderBaseVAO.LinkAttrib(PhoneHolderBaseVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	PhoneHolderBaseVAO.LinkAttrib(PhoneHolderBaseVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	PhoneHolderBaseVAO.LinkAttrib(PhoneHolderBaseVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	PhoneHolderBaseVAO.Unbind();
	PhoneHolderBaseVBO.Unbind();
	PhoneHolderBaseEBO.Unbind();
	//PHONE HOLDER BASE
	//////////////////////////////////////////////////////////////////////////
	VAO PhoneHolderArmVAO;
	PhoneHolderArmVAO.Bind();
	RectPrism PhoneHolderArm(-1.074f, -0.31f, 0.0, 0.25f, 0.0015f, 0.1f);
	VBO PhoneHolderArmVBO(PhoneHolderArm.internalVerts, sizeof(PhoneHolderArm.internalVerts));
	EBO PhoneHolderArmEBO(PhoneHolderArm.Indices, sizeof(PhoneHolderArm.Indices));

	PhoneHolderArmVAO.LinkAttrib(PhoneHolderArmVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	PhoneHolderArmVAO.LinkAttrib(PhoneHolderArmVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	PhoneHolderArmVAO.LinkAttrib(PhoneHolderArmVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	PhoneHolderArmVAO.LinkAttrib(PhoneHolderArmVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	PhoneHolderArmVAO.Unbind();
	PhoneHolderArmVBO.Unbind();
	PhoneHolderArmEBO.Unbind();
	//PHONE HOLDER BASE
	//////////////////////////////////////////////////////////////////////////
	VAO PhoneHolderNubVAO;
	PhoneHolderNubVAO.Bind();
	RectPrism PhoneHolderNub(-0.954f, -0.31f, 0.0, 0.03f, 0.015f, 0.18f);
	VBO PhoneHolderNubVBO(PhoneHolderNub.internalVerts, sizeof(PhoneHolderNub.internalVerts));
	EBO PhoneHolderNubEBO(PhoneHolderNub.Indices, sizeof(PhoneHolderNub.Indices));

	PhoneHolderNubVAO.LinkAttrib(PhoneHolderNubVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	PhoneHolderNubVAO.LinkAttrib(PhoneHolderNubVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	PhoneHolderNubVAO.LinkAttrib(PhoneHolderNubVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	PhoneHolderNubVAO.LinkAttrib(PhoneHolderNubVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	PhoneHolderNubVAO.Unbind();
	PhoneHolderNubVBO.Unbind();
	PhoneHolderNubEBO.Unbind();
	//PHONE HOLDER BASE
	//////////////////////////////////////////////////////////////////////////////////////////////
	VAO DeskLightBaseVAO;
	DeskLightBaseVAO.Bind();
	RectPrism DeskLightBase(1.064f, -0.580f, -1.7, 0.30f, 0.040f, 0.60f);
	VBO DeskLightBaseVBO(DeskLightBase.internalVerts, sizeof(DeskLightBase.internalVerts));
	EBO DeskLightBaseEBO(DeskLightBase.Indices, sizeof(DeskLightBase.Indices));

	DeskLightBaseVAO.LinkAttrib(DeskLightBaseVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	DeskLightBaseVAO.LinkAttrib(DeskLightBaseVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	DeskLightBaseVAO.LinkAttrib(DeskLightBaseVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	DeskLightBaseVAO.LinkAttrib(DeskLightBaseVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));

	DeskLightBaseVAO.Unbind();
	DeskLightBaseVBO.Unbind();
	DeskLightBaseEBO.Unbind();

	//////////////////////////////////////////////////////////////////////////////////////////////

	VAO DeskLightWirelessVAO;
	DeskLightWirelessVAO.Bind();
	RectPrism DeskLightWireless(1.064f, -0.56f, -1.7, 0.20f, 0.0005f, 0.30f);
	VBO DeskLightWirelessVBO(DeskLightWireless.internalVerts, sizeof(DeskLightWireless.internalVerts));
	EBO DeskLightWirelessEBO(DeskLightWireless.Indices, sizeof(DeskLightWireless.Indices));

	DeskLightWirelessVAO.LinkAttrib(DeskLightWirelessVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	DeskLightWirelessVAO.LinkAttrib(DeskLightWirelessVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	DeskLightWirelessVAO.LinkAttrib(DeskLightWirelessVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	DeskLightWirelessVAO.LinkAttrib(DeskLightWirelessVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	DeskLightWirelessVAO.Unbind();
	DeskLightWirelessVBO.Unbind();
	DeskLightWirelessEBO.Unbind();

	//////////////////////////////////////////////////////////////////////////////////////////////
	GLfloat DeskLightStalkLighting[] =

	{
		//FRONT (facing)
		0.0f, 0.5f,  0.8f,
		1.0f, 1.0f,  1.0f, 
		1.0f, 1.0f,  1.0f, 
		1.0f, 1.0f,  1.0f, 
		//BACK (non facing)
		0.0f, 0.5f, -0.8f, // Left Side 4
		0.0f, 0.5f, -0.8f, // Left Side 5
		0.0f, 0.5f, -0.8f, // Left Side 6
		0.0f, 0.5f, -0.8f, // Left Side 7
		//LEFT
		0.8f, 0.5f,  0.0f, // Left Side 8
		0.8f, 0.5f,  0.0f, // Left Side 9   
		0.8f, 0.5f,  0.0f, // Left Side 10
		0.8f, 0.5f,  0.0f, // Left Side 11
		//RIGHT
		-0.8f, 0.5f,  0.0f, // Right side 12
		-0.8f, 0.5f,  0.0f, // Right side 13
		-0.8f, 0.5f,  0.0f, // Right side 14
		-0.8f, 0.5f,  0.0f, // Right side 15
		//TOP
		0.0f, 0.5f, -0.8f, // Facing side 16
		0.0f, 0.5f, -0.8f, // Facing side 17
		0.0f, 0.5f, -0.8f,  // Facing side 18
		0.0f, 0.5f, -0.8f,  // Facing side 19
		//BOTTOM
		0.0f, 0.5f, -0.8f, // Non-facing side 20
		0.0f, 0.5f, -0.8f, // Non-facing side 21
		0.0f, 0.5f, -0.8f, // Non-facing side 22
		0.0f, 0.5f, -0.8f, // Non-facing side 23
	};

	
	VAO DeskLightStalkVAO;
	DeskLightStalkVAO.Bind();
	RectPrism DeskLightStalk(1.064f, -0.21f, -1.9, 0.10f, .7f, 0.06f);
	DeskLightStalk.EditProperties("lighting",24,DeskLightStalkLighting);
	VBO DeskLightStalkVBO(DeskLightStalk.internalVerts, sizeof(DeskLightStalk.internalVerts));
	EBO DeskLightStalkEBO(DeskLightStalk.Indices, sizeof(DeskLightStalk.Indices));

	DeskLightStalkVAO.LinkAttrib(DeskLightStalkVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	DeskLightStalkVAO.LinkAttrib(DeskLightStalkVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	DeskLightStalkVAO.LinkAttrib(DeskLightStalkVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	DeskLightStalkVAO.LinkAttrib(DeskLightStalkVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	DeskLightStalkVAO.Unbind();
	DeskLightStalkVBO.Unbind();
	DeskLightStalkEBO.Unbind();
	//////////////////////////////////////////////////////////////////////////////////////////////
	GLfloat DeskLightTopFixtureLighting[] =

	{
		//FRONT
		0.0f, 0.5f,  0.8f, // Bottom side 0
		0.0f, 0.5f,  0.8f, // Bottom side 1
		0.0f, 0.5f,  0.8f, // Bottom side 2
		0.0f, 0.5f,  0.8f, // Bottom side 3
		//BACK
		0.0f, 0.5f, -0.8f, // Left Side 4
		0.0f, 0.5f, -0.8f, // Left Side 5
		0.0f, 0.5f, -0.8f, // Left Side 6
		0.0f, 0.5f, -0.8f, // Left Side 7
		//LEFT
		0.8f, 0.5f,  0.0f, // Left Side 8
		0.8f, 0.5f,  0.0f, // Left Side 9   
		0.8f, 0.5f,  0.0f, // Left Side 10
		0.8f, 0.5f,  0.0f, // Left Side 11
		//RIGHT
		0.8f, 0.5f,  0.0f, // Right side 12
		0.8f, 0.5f,  0.0f, // Right side 13
		0.8f, 0.5f,  0.0f, // Right side 14
		0.8f, 0.5f,  0.0f, // Right side 15
		//TOP
		0.0f, 0.5f, -0.8f, // Facing side 16
		0.0f, 0.5f, -0.8f, // Facing side 17
		0.0f, 0.5f, -0.8f,  // Facing side 18
		0.0f, 0.5f, -0.8f,  // Facing side 19
		//BOTTOM
		0.0f, 0.5f,  0.8f, // Non-facing side 20
		0.0f, 0.5f,  0.8f, // Non-facing side 21
		0.0f, 0.5f,  0.8f, // Non-facing side 22
		0.0f, 0.5f,  0.8f, // Non-facing side 23
	};

	VAO DeskLightTopFixtureVAO;
	DeskLightTopFixtureVAO.Bind();
	RectPrism DeskLightTopFixture(1.064f, 0.14f, -1.51, 0.10f, 0.040f, 0.75f);
	DeskLightTopFixture.EditProperties("lighting", 24, DeskLightTopFixtureLighting);
	VBO DeskLightTopFixtureVBO(DeskLightTopFixture.internalVerts, sizeof(DeskLightTopFixture.internalVerts));
	EBO DeskLightTopFixtureEBO(DeskLightTopFixture.Indices, sizeof(DeskLightTopFixture.Indices));

	DeskLightStalkVAO.LinkAttrib(DeskLightTopFixtureVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	DeskLightStalkVAO.LinkAttrib(DeskLightTopFixtureVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	DeskLightStalkVAO.LinkAttrib(DeskLightTopFixtureVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	DeskLightStalkVAO.LinkAttrib(DeskLightTopFixtureVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));


	DeskLightTopFixtureVAO.Unbind();
	DeskLightTopFixtureVBO.Unbind();
	DeskLightTopFixtureEBO.Unbind();
	///////////////////////////////////////////////////////////////////////////
	// Shader for light cube
	Shader lightShader("light.vert", "light.frag");
	// Generates Vertex Array Object and binds it
	VAO lightVAO;
	lightVAO.Bind();
	// Generates Vertex Buffer Object and links it to vertices
	VBO lightVBO(lightVertices, sizeof(lightVertices));
	// Generates Element Buffer Object and links it to indices
	EBO lightEBO(lightIndices, sizeof(lightIndices));
	// Links VBO attributes such as coordinates and colors to VAO
	lightVAO.LinkAttrib(lightVBO, 0, 3, GL_FLOAT, 3 * sizeof(float), (void*)0);
	// Unbind all to prevent accidentally modifying them
	lightVAO.Unbind();
	lightVBO.Unbind();
	lightEBO.Unbind();



	glm::vec4 lightColor = glm::vec4(1.0f, 0.5f, 1.0f, 1.0f);
	glm::vec3 lightPos = glm::vec3(0.5f, 0.5f, 0.5f);
	glm::mat4 lightModel = glm::mat4(1.0f);
	lightModel = glm::translate(lightModel, lightPos);

	glm::vec3 pyramidPos = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::mat4 pyramidModel = glm::mat4(1.0f);
	pyramidModel = glm::translate(pyramidModel, pyramidPos);


	lightShader.Activate();
	glUniformMatrix4fv(glGetUniformLocation(lightShader.ID, "model"), 1, GL_FALSE, glm::value_ptr(lightModel));
	glUniform4f(glGetUniformLocation(lightShader.ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	shaderProgram.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram.ID, "model"), 1, GL_FALSE, glm::value_ptr(pyramidModel));
	glUniform4f(glGetUniformLocation(shaderProgram.ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	glUniform3f(glGetUniformLocation(shaderProgram.ID, "lightPos"), lightPos.x, lightPos.y, lightPos.z);

	//LIGHTING 1
	///////////////////////////////////////////////////////////////////////////
		// Shader for light cube
	Shader lightShader2("light.vert", "light.frag");
	// Generates Vertex Array Object and binds it
	VAO lightVAO2;
	lightVAO2.Bind();
	// Generates Vertex Buffer Object and links it to vertices
	VBO lightVBO2(lightVertices2, sizeof(lightVertices2));
	// Generates Element Buffer Object and links it to indices
	EBO lightEBO2(lightIndices, sizeof(lightIndices));
	// Links VBO attributes such as coordinates and colors to VAO
	lightVAO2.LinkAttrib(lightVBO2, 0, 3, GL_FLOAT, 3 * sizeof(float), (void*)0);
	// Unbind all to prevent accidentally modifying them
	lightVAO2.Unbind();
	lightVBO2.Unbind();
	lightEBO2.Unbind();

	glm::vec4 lightColor2 = glm::vec4(0.5f, 1.0f, 1.0f, 1.0f);
	glm::vec3 lightPos2 = glm::vec3(0.5f, 0.5f, 0.5f);
	glm::mat4 lightModel2 = glm::mat4(1.0f);
	lightModel2 = glm::translate(lightModel2, lightPos2);

	glm::vec3 pyramidPos2 = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::mat4 pyramidModel2 = glm::mat4(1.0f);
	pyramidModel2 = glm::translate(pyramidModel, pyramidPos);


	lightShader2.Activate();
	glUniformMatrix4fv(glGetUniformLocation(lightShader2.ID, "model"), 1, GL_FALSE, glm::value_ptr(lightModel2));
	glUniform4f(glGetUniformLocation(lightShader2.ID, "lightColor"), lightColor2.x, lightColor2.y, lightColor2.z, lightColor2.w);
	shaderProgram.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram.ID, "model"), 1, GL_FALSE, glm::value_ptr(pyramidModel));
	glUniform4f(glGetUniformLocation(shaderProgram.ID, "lightColor"), lightColor2.x, lightColor2.y, lightColor2.z, lightColor2.w);
	glUniform3f(glGetUniformLocation(shaderProgram.ID, "lightPos"), lightPos2.x, lightPos2.y, lightPos2.z);

	//LIGHTING 2
	///////////////////////////////////////////////////////////////////////////
	// 
	// Textures + Setup
	Texture brickTex("brick.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	brickTex.texUnit(shaderProgram, "tex0", 0);

	Texture wirelessTex("wireless.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	wirelessTex.texUnit(shaderProgram, "tex0", 0);

	Texture marbleTex("marble.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	marbleTex.texUnit(shaderProgram, "tex0", 0);

	Texture woodTex("container2.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	woodTex.texUnit(shaderProgram, "tex0", 0);

	Texture KeyboardTex("Keyboard.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	KeyboardTex.texUnit(shaderProgram, "tex0", 0);

	Texture pinkMetalTex("pinkmetallic.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	pinkMetalTex.texUnit(shaderProgram, "tex0", 0);

	Texture blackMetalTex("blackmetal.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	blackMetalTex.texUnit(shaderProgram, "tex0", 0);

	Texture homePageTex("internet.png", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	homePageTex.texUnit(shaderProgram, "tex0", 0);
	//TEXTURES+SETUP
	///////////////////////////////////////////////////////////////////////////
	// Enables the Depth Buffer
	glEnable(GL_DEPTH_TEST);

	// Creates camera object
	

	// Main while loop
	while (!glfwWindowShouldClose(window))
	{
		// Specify the color of the background
		glClearColor(0.07f, 0.13f, 0.17f, 1.0f);
		// Clean the back buffer and depth buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		// Handles camera inputs
		HostCamera.Inputs(window);
		// Updates and exports the camera matrix to the Vertex Shader
		HostCamera.updateMatrix(45.0f, 0.1f, 100.0f);

		// Tells OpenGL which Shader Program we want to use
		shaderProgram.Activate();
		// Exports the camera Position to the Fragment Shader for specular lighting
		glUniform3f(glGetUniformLocation(shaderProgram.ID, "camPos"), HostCamera.Position.x, HostCamera.Position.y, HostCamera.Position.z);
		// Export the camMatrix to the Vertex Shader of the pyramid
		HostCamera.Matrix(shaderProgram, "camMatrix");



		
		////////////////////////////////////////////////////////////////////////////////////////
		// Binds texture so that is appears in rendering
		pinkMetalTex.Bind();
		//Bind the VAO so OpenGL knows to use it
		PhoneHolderStalkVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(basePlate.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		PhoneHolderBaseVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(basePlate.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		PhoneHolderArmVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(basePlate.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		PhoneHolderNubVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(basePlate.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);

		////////////////////////////////////////////////////////////////////////////////////////
		// Binds texture so that is appears in rendering
		marbleTex.Bind();
		//Bind the VAO so OpenGL knows to use it
		basePlateVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(basePlate.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);



		////////////////////////////////////////////////////////////////////////////////////////
		KeyboardTex.Bind();
		//Bind the VAO so OpenGL knows to use it
		KeyboardVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(Keyboard.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		////////////////////////////////////////////////////////////////////////////////////////
		

		////////////////////////////////////////////////////////////////////////////////////////
		blackMetalTex.Bind();
		//Bind the VAO so OpenGL knows to use it
		DeskLightBaseVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(DeskLightBase.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		DeskLightStalkVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(DeskLightStalk.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		//Bind the VAO so OpenGL knows to use it
		DeskLightTopFixtureVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(DeskLightTopFixture.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		////////////////////////////////////////////////////////////////////////////////////////
		
		MonitorBodyVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(MonitorBody.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		MonitorBaseVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(MonitorBase.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		MonitorStalkVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(MonitorStalk.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);

		homePageTex.Bind();
		MonitorContentVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(MonitorStalk.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);


		////////////////////////////////////////////////////////////////////////////////////////
		wirelessTex.Bind();
		//Bind the VAO so OpenGL knows to use it
		DeskLightWirelessVAO.Bind();
		//Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(DeskLightWireless.Indices) / sizeof(int), GL_UNSIGNED_INT, 0);


		////////////////////////////////////////////////////////////////////////////////////////
		
		// Tells OpenGL which Shader Program we want to use
		lightShader2.Activate();
		// Export the camMatrix to the Vertex Shader of the light cube
		HostCamera.Matrix(lightShader2, "camMatrix");

		lightVAO2.Bind();
		// Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(lightIndices) / sizeof(int), GL_UNSIGNED_INT, 0);

		// Tells OpenGL which Shader Program we want to use
		lightShader.Activate();
		// Export the camMatrix to the Vertex Shader of the light cube
		HostCamera.Matrix(lightShader, "camMatrix");
		// Bind the VAO so OpenGL knows to use it
		lightVAO.Bind();
		// Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(lightIndices) / sizeof(int), GL_UNSIGNED_INT, 0);




		// Swap the back buffer with the front buffer
		glfwSwapBuffers(window);
		// Take care of all GLFW events
		glfwPollEvents();
	}



	// Delete all the objects we've created
	VAO1.Delete();
	VBO1.Delete();
	EBO1.Delete();
	brickTex.Delete();
	shaderProgram.Delete();
	lightVAO.Delete();
	lightVBO.Delete();
	lightEBO.Delete();
	lightShader.Delete();
	// Delete window before ending the program
	glfwDestroyWindow(window);
	// Terminate GLFW before ending the program
	glfwTerminate();
	return 0;
}

void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	HostCamera.speed += yoffset;
	HostCamera.speed = std::fmaxf(HostCamera.speed, 1);
	HostCamera.speed = std::fminf(HostCamera.speed, 100);

}
