#ifndef CUBE_H
#define CUBE_H

#include "VBO.H"
#include<glad/glad.h>
#include<string>
#include<fstream>
#include<sstream>
#include<iostream>
#include<cerrno>

class Cube
{
public:
	// Reference ID of the Shader Program
	GLuint Scale;
	GLfloat internalVerts[192] = {};
	GLfloat originX;
	GLfloat originY;
	GLfloat originZ;

	GLuint Indices[36] = 
	{ 
		/////////////FRONT
		4,7,6,
		5,4,6,
		/////////////BACK
		0,1,2,
		0,3,2,
		/////////////LEFT
		11,9,8,
		11,9,10,
		
		/////////////RIGHT
		14,12,13,
		14,12,15,
		
		/////////////TOP
		17,16,18,
		19,18,16,
		
		////////////BOTTOM
		21,20,22,
		20,22,23,
		
	};


	//std::array<GLfloat, 28> internalVerts={};
	// Constructor that build the cube from.......
	Cube(GLfloat centerPosX, GLfloat centerPosY, GLfloat centerPosZ, GLfloat edgeLength, GLfloat Scale);

private:
	// Checks if the different Shaders have compiled properly
	void compileErrors(unsigned int shader, const char* type);
};



#endif